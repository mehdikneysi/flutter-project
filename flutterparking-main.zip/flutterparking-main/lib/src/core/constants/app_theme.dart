import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData light = ThemeData(scaffoldBackgroundColor: Colors.white);
}
