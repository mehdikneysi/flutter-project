import 'package:flutter/material.dart';

class AppColors {
  static const principalColor = Color.fromRGBO(253, 172, 65, 1);
  static const secundaryBackgroudColor = Color.fromRGBO(38, 39, 48, 1);
  static const primaryBackgroudColor = Color.fromRGBO(29, 29, 39, 1);
}
