import 'package:flutter/material.dart';

const appName = 'Flutter parking app';
const TextStyle titleSecound =
    TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16);
