import 'spot.dart';

class SpotSection {
  final List<Spot> spots;

  SpotSection({
    required this.spots,
  });
}
