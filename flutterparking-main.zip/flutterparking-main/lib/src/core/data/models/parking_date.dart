// TODO Implement this library.class ParkingDate
class ParkingDate {
  final String month;
  final int dayOfMonth;
  final List<String> times;

  ParkingDate(this.month, this.dayOfMonth, this.times);
}