class Category {
  final String name;
  final String icon;

  Category({
    required this.name,
    required this.icon,
  });
}
