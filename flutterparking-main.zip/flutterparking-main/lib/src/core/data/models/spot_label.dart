import 'package:flutter/material.dart';

class SpotLabel {
  final String name;
  final Color color;

  SpotLabel(this.name, this.color);
}
