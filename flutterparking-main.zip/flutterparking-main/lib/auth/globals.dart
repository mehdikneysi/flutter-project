// TODO Implement this library.
library my_prj.globals;

bool isLoggedIn = false;